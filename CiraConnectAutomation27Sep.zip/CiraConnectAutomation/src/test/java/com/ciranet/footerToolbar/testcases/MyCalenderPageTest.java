package com.ciranet.footerToolbar.testcases;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import org.testng.annotations.Test;

import com.ciranet.constants.Constants;
import com.ciranet.footerToolbar.pages.MyCalenderPage;
import com.ciranet.testbase.TestBase;
import com.ciranet.utilities.LoggerManager;
import com.ciranet.utilities.RequiresLogin;

@RequiresLogin
public class MyCalenderPageTest extends TestBase
{
	MyCalenderPage	myCalender = createPage(MyCalenderPage.class);

	@Test(priority = 0, description = "Verify My Calendar", groups = {Constants.SMOKE_TESTING}, alwaysRun=true)
	public void verifyCalendar()
	{
		LoggerManager.info("Verifying My Calendar footer toolbar menu");
		TestBase.setExtentReportSettings("Verifying My Calendar lable", Constants.SMOKE_TESTING,"My Calendar", "Verify My Calendar");
		myCalender = new MyCalenderPage(driver);
		assertEquals(myCalender.verifyCalendar(),"My Calendar");
	}

	@Test(priority = 1, description = "Verifying My Calendar footer switching tabs", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifySwitchingTabs()
	{
		LoggerManager.info("Verifying My Calendar footer switching tabs");
		TestBase.setExtentReportSettings("Verifying My Calendar SwitchingTabs", Constants.FUNCTIONAL_TESTING,"My Calendar All Events SwitchingTabs", "Verify My Calendar SwitchingTabs");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifySwitchingTabs(), "Switching Tabs are not seen");

	}

	@Test(priority = 2, description = "Verifying My Calendar Lite Mode button status", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifyLiteModeButton()
	{
		LoggerManager.info("Verifying My Calendar Lite Mode button status");
		TestBase.setExtentReportSettings("Verifying My Calendar Lite Mode button status", Constants.FUNCTIONAL_TESTING,"My Calendar Lite Mode button status", "Verify My Calendar Lite Mode button status");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifyLiteModeButton(),"Lite Mode toggle button status are not seen");
	}

	@Test(priority = 3, description = "Verifying My Calendar Add New button appointment Daily", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifyAddNewButtonappointmentDaily()
	{
		LoggerManager.info("Verifying My Calendar Appointment popup Daily");
		TestBase.setExtentReportSettings("Verifying My Calendar Add New button appointment Daily", Constants.FUNCTIONAL_TESTING,"Add New button appointment Daily", "Verify My Calendar Add New button appointment Daily");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifyAddNewButtonappointmentDaily(),"Add New button appointment Daily is not seen");
	}

	@Test(priority = 4, description = "Verifying My Calendar Add New button appointment Weekly", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifyAddNewButtonappointmentWeekly()
	{
		LoggerManager.info("Verifying My Calendar Appointment popup Weekly");
		TestBase.setExtentReportSettings("Verifying My Calendar Add New button appointment Weekly", Constants.FUNCTIONAL_TESTING,"Add New button appointment Weekly", "Verify My Calendar Add New button appointment Weekly");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifyAddNewButtonappointmentWeekly(),"Add New button appointment Weekly is not seen");
	}

	@Test(priority = 5, description = "Verifying My Calendar Add New button appointment Monthly", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifyAddNewButtonappointmentMonthly()
	{
		LoggerManager.info("Verifying My Calendar Appointment popup Monthly");
		TestBase.setExtentReportSettings("Verifying My Calendar Add New button appointment Monthly", Constants.FUNCTIONAL_TESTING,"Add New button appointment Monthly", "Verify My Calendar Add New button appointment Monthly");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifyAddNewButtonappointmentMonthly(),"Add New button appointment Monthly is not seen");
	}

	@Test(priority = 6, description = "Verifying My Calendar Add New button appointment Yearly", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifyAddNewButtonappointmentYearly()
	{
		LoggerManager.info("Verifying My Calendar Appointment popup Yearly");
		TestBase.setExtentReportSettings("Verifying My Calendar Add New button appointment Yearly", Constants.FUNCTIONAL_TESTING,"Add New button appointment Yearly", "Verify My Calendar Add New button appointment Yearly");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifyAddNewButtonappointmentYearly(),"Add New button appointment Yearly is not seen");
	}

	@Test(priority = 7, description = "Verifying My Calendar Add New button Recurring Appointment Daily", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifyAddNewButtonrecurringAppointment()
	{
		LoggerManager.info("Verifying My Calendar Recurring Appointment popup Daily");
		TestBase.setExtentReportSettings("Verifying My Calendar Add New button Recurring Appointment Daily", Constants.FUNCTIONAL_TESTING,"Add New button Recurring Appointment Daily", "Verify My Calendar Add New button Recurring Appointment Daily");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifyAddNewButtonrecurringAppointmentDaily(),"Add New button Recurring Appointment Daily is not seen");

	}

	@Test(priority = 8, description = "Verifying My Calendar Add New button Recurring Appointment Weekly", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifyAddNewButtonrecurringAppointmentWeekly()
	{
		LoggerManager.info("Verifying My Calendar Recurring Appointment popup Weekly");
		TestBase.setExtentReportSettings("Verifying My Calendar Add New button Recurring Appointment Weekly", Constants.FUNCTIONAL_TESTING,"Add New button Recurring Appointment Weekly", "Verify My Calendar Add New button Recurring Appointment Weekly");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifyAddNewButtonrecurringAppointmentWeekly(),"Add New button Recurring Appointment Weekly is not seen");

	}

	@Test(priority = 9, description = "Verifying My Calendar Add New button Recurring Appointment Monthly", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifyAddNewButtonrecurringAppointmentMonthly()
	{
		LoggerManager.info("Verifying My Calendar Recurring Appointment popup Monthly");
		TestBase.setExtentReportSettings("Verifying My Calendar Add New button Recurring Appointment Monthly", Constants.FUNCTIONAL_TESTING,"Add New button Recurring Appointment Monthly", "Verify My Calendar Add New button Recurring Appointment Monthly");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifyAddNewButtonrecurringAppointmentMonthly(),"Add New button Recurring Appointment Monthly is not seen");

	}

	@Test(priority = 10, description = "Verifying My Calendar Add New button Recurring Appointment Yearly", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifyAddNewButtonrecurringAppointmentYearly()
	{
		LoggerManager.info("Verifying My Calendar Recurring Appointment popup Yearly");
		TestBase.setExtentReportSettings("Verifying My Calendar Add New button Recurring Appointment Yearly", Constants.FUNCTIONAL_TESTING,"Add New button Recurring Appointment Yearly", "Verify My Calendar Add New button Recurring Appointment Yearly");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifyAddNewButtonrecurringAppointmentYearly(),"Add New button Recurring Appointment Yearly is not seen");

	}

	@Test(priority = 11, description = "Verifying My Calendar day Wise Calender Community Tab", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifydayWiseCalenderCommunityTab()
	{
		LoggerManager.info("Verifying My Calendar day Wise Calender Community Tab");
		TestBase.setExtentReportSettings("Verifying My Calendar day Wise Calender Community Tab", Constants.FUNCTIONAL_TESTING,"day Wise Calender CommunityTab", "Verify My Calendar day Wise Calender Community Tab");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifydayWiseCalenderCommunityTab(),"day Wise Calender Community Tab is not seen");
	}

	@Test(priority = 12, description = "Verifying My Calendar WorkWeek Wise Calender CommunityTab", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifyWorkWeekWiseCalenderCommunityTab()
	{
		LoggerManager.info("Verifying My Calendar WorkWeek Wise Calender Community Tab");
		TestBase.setExtentReportSettings("Verifying My Calendar WorkWeek Wise Calender Community Tab", Constants.FUNCTIONAL_TESTING,"WorkWeek Wise Calender CommunityTab", "Verify My Calendar WorkWeek Wise Calender Community Tab");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifyWorkWeekWiseCalenderCommunityTab(),"WorkWeek Wise Calender Community Tab is not seen");
	}
	@Test(priority = 13, description = "Verifying My Calendar Week Wise Calender CommunityTab", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifyWeekWiseCalenderCommunityTab()
	{
		LoggerManager.info("Verifying My Calendar Week Wise Calender Community Tab");
		TestBase.setExtentReportSettings("Verifying My Calendar Week Wise Calender Community Tab", Constants.FUNCTIONAL_TESTING,"Week Wise Calender CommunityTab", "Verify My Calendar Week Wise Calender Community Tab");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifyWeekWiseCalenderCommunityTab(),"Week Wise Calender Community Tab is not seen");
	}

	@Test(priority = 14, description = "Verifying My Calendar Month Wise Calender CommunityTab", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifyMonthWiseCalenderCommunityTab()
	{
		LoggerManager.info("Verifying My Calendar Month Wise Calender Community Tab");
		TestBase.setExtentReportSettings("Verifying My Calendar Month Wise Calender Community Tab", Constants.FUNCTIONAL_TESTING,"Month Wise Calender CommunityTab", "Verify My Calendar Month Wise Calender Community Tab");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifyMonthWiseCalenderCommunityTab(),"Month Wise Calender Community Tab is not seen");
	}

	@Test(priority = 15, description = "Verifying My Calendar Timeline Wise Calender Community Tab", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifytimelineWiseCalenderCommunityTab()
	{
		LoggerManager.info("Verifying My Calendar Timeline Wise Calender Community Tab");
		TestBase.setExtentReportSettings("Verifying My Calendar Timeline Wise Calender Community Tab", Constants.FUNCTIONAL_TESTING,"Timeline Wise Calender CommunityTab", "Verify My Calendar Timeline Wise Calender Community Tab");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifytimelineWiseCalenderCommunityTab(),"Timeline Wise Calender Community Tab is not seen");
	}
	

	@Test(priority = 16, description = "Verifying My Calendar Timeline Wise Calender Community Tab", groups = {Constants.FUNCTIONAL_TESTING}, alwaysRun=true)
	public void verifyExportbutton()
	{
		LoggerManager.info("Verifying My Calendar Export button");
		TestBase.setExtentReportSettings("Verifying My Calendar Export button", Constants.FUNCTIONAL_TESTING,"Export button", "Verify My Calendar Export button");
		myCalender = new MyCalenderPage(driver);
		assertTrue(myCalender.verifyExportbutton(),"Export button is not seen");
	}

}

