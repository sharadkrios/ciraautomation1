package com.ciranet.footerToolbar.pages;

import java.awt.AWTException;
import java.awt.Robot;
import java.awt.event.KeyEvent;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

import com.ciranet.basepage.BasePage;

public class MyCalenderPage extends BasePage 
{
	public MyCalenderPage(WebDriver driver) 
	{
		super(driver);
	}

	@FindBy(xpath = "//i[@class='dx-icon fas fa-calendar-alt']")
	WebElement calendar;

	//@FindBy(xpath = "dx-loadindicator-icon")
	@FindBy(xpath = "//div[@class='dx-loadpanel-content-wrapper']")
	WebElement loaderIcon;

	@FindBy(xpath = "//h2[@class='page-header']")
	WebElement lblmyCalendar;

	@FindBy(xpath = "(//div[@class='dx-dropdowneditor-icon'])[1]")
	WebElement locationdropdown;

	@FindBy(xpath = "//div[@class='dx-treelist-text-content'][contains(.,'RealManage')]")
	WebElement locationdropdownValue;

	@FindBy(xpath = "(//span[contains(@class,'dx-checkbox-icon')])[3]")
	WebElement locationdropdownAustinValue;

	@FindBy(xpath = "(//div[@class='dx-toolbar-items-container'])[1]")
	WebElement clickSide;

	@FindBy(xpath = "//div[@class='dx-tag-remove-button']")
	WebElement removeSelection;

	@FindBy(xpath = "(//span[@class='dx-icon dx-icon-clear'])[2]")
	WebElement clearSelection;

	@FindBy(xpath = "//span[normalize-space()='Refresh']")
	WebElement refreshButton;

	@FindBy(xpath = "//span[@class='dx-tab-text'][contains(.,'Community')]")
	WebElement communityTab;

	@FindBy(xpath = "//span[@class='dx-tab-text'][contains(.,'Amenity')]")
	WebElement amenityTab;

	@FindBy(xpath = "//span[normalize-space()='Add New']")
	WebElement addNewButton;

	@FindBy(xpath = "//div[@class='action-option-container'][normalize-space()='Appointment']")
	WebElement appointmentButton;

	@FindBy(xpath = "(//div[contains(@class,'dx-dropdowneditor-icon')])[4]")
	WebElement communityAppointmentdropdown;

	@FindBy(xpath = "//input[contains(@aria-expanded,'true')]")
	WebElement selectcommunityAppointmentdropdown;

	@FindBy(xpath = "//span[contains(.,'1100 Trinity Mills Condos')]")
	WebElement communityAppointmentdropdownValue;

	@FindBy(xpath = "(//input[@aria-required='true'])[4]")
	WebElement subjectAppointmentTextBox;

	@FindBy(xpath = "//textarea[@aria-required='true']")
	WebElement descriptionAppointmentTextBox;

	@FindBy(xpath = "(//div[@class='dx-switch-off'][normalize-space()='No'])[1]")
	WebElement allDay;

	@FindBy(xpath = "(//div[@class='dx-switch-off'][normalize-space()='No'])[2]")
	WebElement visibleinResidentPortal;

	@FindBy(xpath = "(//div[@class='dx-switch-off'][normalize-space()='No'])[3]")
	WebElement recurrence;

	@FindBy(xpath = "(//div[@class='dx-switch-off'][normalize-space()='No'])[3]")
	WebElement recurrencedaily;

	@FindBy(xpath = "(//div[@class='dx-radiobutton-icon'])[1]")
	WebElement recurrenceWeekly;

	@FindBy(xpath = "(//div[@class='dx-numberbox-spin-up-icon'])[2]")
	WebElement recureveryWeeks;

	@FindBy(xpath = "(//div[@class='dx-radiobutton-icon'])[9]")
	WebElement endby;

	@FindBy(xpath = "(//input[@aria-expanded='false'])[15]")
	WebElement endbydate;

	@FindBy(xpath = "//i[@class='dx-icon fas fa-check']")
	WebElement okAppointmentButton;

	@FindBy(xpath = "//div[@class='dx-popup-content'][contains(.,'Context is required.Close')]")
	WebElement contextisrequiredClosepopup;

	@FindBy(xpath = "//div[@class='dx-overlay-content dx-toast-success dx-toast-content dx-resizable']")
	WebElement messageElement;

	@FindBy(xpath = "//div[contains(text(),'Recurring Appointment')]")
	WebElement recurringAppointment;

	@FindBy(xpath = "(//input[@class='dx-texteditor-input'])[5]")
	WebElement communityrecurringAppointmentdropdown;

	@FindBy(xpath = "//span[contains(.,'1100 Trinity Mills Condos')]")
	WebElement selectcommunityrecurringAppointmentdropdown;

	@FindBy(xpath = "//span[normalize-space()='1100 Trinity Mills Condos']")
	WebElement communityrecurringAppointmentdropdownValue;

	@FindBy(xpath = "(//div[@class='dx-dropdowneditor-icon'])[8]")
	WebElement labelTyperecurringAppointmentdropdown;

	@FindBy(xpath = "//div[contains(text(),'BOD Related')]")
	WebElement labelTyperecurringAppointmentdropdownValue;

	@FindBy(xpath = "(//input[@aria-required='true'])[4]")
	WebElement subjectrecurringAppointmentTextBox;

	@FindBy(xpath = "//textarea[@aria-required='true']")
	WebElement descriptionrecurringAppointmentTextBox;

	@FindBy(xpath = "//dx-button[@title='Ok']//div[@class='dx-button-content']")
	WebElement okrecurringAppointmentButton;

	@FindBy(xpath = "//span[normalize-space()='Add New Amenity Event']")
	WebElement addNewAmenityEventButton;

	@FindBy(xpath = "(//div[@class='dx-dropdowneditor-icon'])[2]")
	WebElement labeldropdown;

	//@FindBy(xpath = "(//span[@class='dx-checkbox-icon'])[19]")
	@FindBy(xpath = "(//span[contains(@class,'dx-checkbox-icon')])[19]")
	WebElement labeldropdownValue;

	@FindBy(xpath = "(//div[@class='dx-dropdowneditor-icon'])[3]")
	WebElement labelTypedropdown;

	@FindBy(xpath = "(//span[@class='dx-checkbox-icon'])[25]")
	WebElement labelTypedropdownValue;

	@FindBy(xpath = "//div[@class='dx-switch-on'][contains(.,'ON')]")
	WebElement liteModeButtonOn;

	@FindBy(xpath = "//div[@class='dx-switch-off'][contains(.,'OFF')]")
	WebElement liteModeButtonOff;

	@FindBy(xpath = "(//div[@class='dx-radiobutton-icon'])[2]")
	WebElement recurrenceMonthly;

	@FindBy(xpath = "(//div[@class='dx-numberbox-spin-up-icon'])[3]")
	WebElement monthlyDaydropdownValue;

	@FindBy(xpath = "(//div[@class='dx-numberbox-spin-up-icon'])[4]")
	WebElement monthlyEverymonthsdropdownValue;

	@FindBy(xpath = "(//div[@class='dx-radiobutton-icon'])[8]")
	WebElement monthlyendby;

	@FindBy(xpath = "//dx-date-box[@type='date']//input[@role='combobox']")
	WebElement monthlyendbydate;

	@FindBy(xpath = "(//div[contains(@class,'dx-radiobutton-icon')])[7]")
	WebElement recurrenceYearly;

	@FindBy(xpath = "(//div[@class='dx-dropdowneditor-icon'])[11]")
	WebElement yearlyEveryDropdown;

	@FindBy(xpath = "//div[contains(text(),'January')]")
	WebElement yearlyEveryJanuary;

	@FindBy(xpath = "(//div[@class='dx-numberbox-spin-up-icon'])[6]")
	WebElement yearlyEverynumberdropdwon;

	@FindBy(xpath = "(//div[@class='dx-radiobutton-icon'])[9]")
	WebElement yearlyendby;

	@FindBy(xpath = "(//dx-date-box[@type='date']//input[@role='combobox'])[1]")
	WebElement yearlyendbydate;

	@FindBy(xpath = "(//div[@class='dx-radiobutton-icon'])[1]")
	WebElement recurringAppointmentRecurrenceWeekly;

	@FindBy(xpath = "(//div[@class='dx-numberbox-spin-up-icon'])[2]")
	WebElement recurringAppointmentRecureveryWeeks;

	@FindBy(xpath = "(//div[@class='dx-radiobutton-icon'])[9]")
	WebElement recurringAppointmentendby;

	@FindBy(xpath = "//dx-date-box[@type='date']//input[@role='combobox']")
	WebElement recurringAppointmentendbydate;

	@FindBy(xpath = "(//div[@class='dx-radiobutton-icon'])[2]")
	WebElement recurringAppointmentMonthly;

	@FindBy(xpath = "(//div[@class='dx-numberbox-spin-up-icon'])[3]")
	WebElement recurringAppointmentmonthlyDaydropdownValue;

	@FindBy(xpath = "(//div[@class='dx-numberbox-spin-up-icon'])[4]")
	WebElement recurringAppointmentmonthlydropdownValue;

	@FindBy(xpath = "(//div[@class='dx-radiobutton-icon'])[8]")
	WebElement recurringAppointmentMonthlyendby;

	@FindBy(xpath = "//dx-date-box[@type='date']//input[@role='combobox']")
	WebElement recurringAppointmentMonthlyendbydate;

	@FindBy(xpath = "(//div[contains(@class,'dx-radiobutton-icon')])[7]")
	WebElement recurringAppointmentRecurrenceYearly;

	@FindBy(xpath = "(//div[@class='dx-dropdowneditor-icon'])[11]")
	WebElement recurringAppointmentYearlyEveryDropdown;

	@FindBy(xpath = "//div[contains(text(),'January')]")
	WebElement recurringAppointmentYearlyEveryJanuary;

	@FindBy(xpath = "(//div[@class='dx-numberbox-spin-up-icon'])[6]")
	WebElement recurringAppointmentYearlyEverynumberdropdwon;

	@FindBy(xpath = "(//div[@class='dx-radiobutton-icon'])[9]")
	WebElement recurringAppointmentYearlyendby;

	@FindBy(xpath = "(//dx-date-box[@type='date']//input[@role='combobox'])[1]")
	WebElement recurringAppointmentYearlyendbydate;

	@FindBy(xpath = "//span[normalize-space()='Day']")
	WebElement daySelection;

	@FindBy(xpath = "//span[normalize-space()='Work Week']")
	WebElement workWeekSelection;

	@FindBy(xpath = "//span[normalize-space()='Week']")
	WebElement weekSelection;

	@FindBy(xpath = "//span[normalize-space()='Month']")
	WebElement monthSelection;

	@FindBy(xpath = "//span[normalize-space()='Timeline']")
	WebElement timelineSelection;

	@FindBy(xpath = "//i[@class='dx-icon dx-icon-download']")
	WebElement exportButton;

	public void selectDropdown() throws AWTException 
	{
		if (isElementDisplayed(clearSelection))
		{
			System.out.println("location dropdown Austin Value is already selected, selecting it now.");
		}
		else
		{
			clickElementJS(locationdropdown);
			waitForInvisibility(loaderIcon);

			clickElementJS(locationdropdownValue);
			waitForInvisibility(loaderIcon);

			System.out.println("location dropdown Austin Value is not selected, selecting it now.");
			clickElementJS(locationdropdownAustinValue); // Select the checkbox
			waitForInvisibility(loaderIcon);

			clickElement(clickSide);

			clickElementJS(refreshButton);
			waitForInvisibility(loaderIcon);

		}
	}

	public void pressEscapeKey() throws AWTException 
	{
		Robot robot = new Robot();
		robot.keyPress(KeyEvent.VK_ESCAPE);
		robot.keyRelease(KeyEvent.VK_ESCAPE);
	}

	public void AddNewButtonappointment() throws AWTException 
	{

		clickElementJS(addNewButton);

		waitForElementToBeVisible(appointmentButton);
		clickElementJS(appointmentButton);
		waitForInvisibility(loaderIcon);

		waitForElementToBeVisible(okAppointmentButton);
		clickElementJS(communityAppointmentdropdown);
		waitForInvisibility(loaderIcon);

		clickElementJS(communityAppointmentdropdownValue);
		waitForInvisibility(loaderIcon);

		clickElement(allDay);

		clickElement(subjectAppointmentTextBox);
		subjectAppointmentTextBox.sendKeys("1100 Trinity Mills Condos");
		waitForInvisibility(loaderIcon);

		clickElement(descriptionAppointmentTextBox);
		descriptionAppointmentTextBox.sendKeys("1100 Trinity Mills Condos");
		waitForInvisibility(loaderIcon);

		// Scroll to the element using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", visibleinResidentPortal);

		// Click the element
		clickElement(visibleinResidentPortal);
		waitForInvisibility(loaderIcon);

	}

	public void contextisrequiredClosepopup() throws AWTException 
	{
		if (isElementDisplayed(contextisrequiredClosepopup))
		{
			try 
			{
				pressEscapeKey();
				waitForInvisibility(loaderIcon);
			} 
			catch (AWTException e) 
			{
				e.printStackTrace();
			}
		}
	}

	public void recurringAppointmentendbySelections() 
	{
		// Scroll to the element using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", recurringAppointmentendby);

		clickElement(recurringAppointmentendby);

		// Get today's date
		LocalDate today = LocalDate.now();

		// Add one day to get tomorrow's date
		LocalDate tomorrow = today.plusDays(1);

		// Define the date format you need
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

		// Format tomorrow's date as a string
		String tomorrowDate = tomorrow.format(formatter);

		// Use sendKeys to enter tomorrow's date in the web element
		// Assuming addEditAnnouncementExpires is the WebElement for the expiration date field
		recurringAppointmentendbydate.sendKeys(tomorrowDate);
		waitForInvisibility(loaderIcon);

		clickElement(okAppointmentButton);
		waitForInvisibility(loaderIcon);
	}

	public void endbySelections() 
	{
		// Scroll to the element using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", endby);

		clickElement(endby);

		// Get today's date
		LocalDate today = LocalDate.now();

		// Add one day to get tomorrow's date
		LocalDate tomorrow = today.plusDays(1);

		// Define the date format you need
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

		// Format tomorrow's date as a string
		String tomorrowDate = tomorrow.format(formatter);

		// Use sendKeys to enter tomorrow's date in the web element
		// Assuming addEditAnnouncementExpires is the WebElement for the expiration date field
		endbydate.sendKeys(tomorrowDate);
		waitForInvisibility(loaderIcon);

		clickElement(okAppointmentButton);
		waitForInvisibility(loaderIcon);
	}

	public void AddNewButtonrecurringAppointment()
	{
		clickElementJS(addNewButton);

		waitForElementToBeVisible(recurringAppointment);
		clickElementJS(recurringAppointment);

		waitForElementToBeVisible(okrecurringAppointmentButton);

		clickElementJS(communityrecurringAppointmentdropdown);
		waitForInvisibility(loaderIcon);

		clickElementJS(communityrecurringAppointmentdropdownValue);
		waitForInvisibility(loaderIcon);

		clickElement(allDay);

		clickElementJS(labelTyperecurringAppointmentdropdown);
		waitForInvisibility(loaderIcon);
		waitForElementToBeVisible(labelTyperecurringAppointmentdropdownValue);
		clickElementJS(labelTyperecurringAppointmentdropdownValue);
		waitForInvisibility(loaderIcon);

		clickElementJS(subjectrecurringAppointmentTextBox);
		subjectrecurringAppointmentTextBox.sendKeys("1100 Trinity Mills Condos");
		waitForInvisibility(loaderIcon);

		clickElementJS(descriptionrecurringAppointmentTextBox);
		descriptionrecurringAppointmentTextBox.sendKeys("1100 Trinity Mills Condos");
		waitForInvisibility(loaderIcon);

	}

	public void labelTypeDropdownSelection()
	{

		if (isElementDisplayed(removeSelection))
		{
			System.out.println("label dropdown Value is  already selected, selecting it now.");
		}
		else
		{
			waitForInvisibility(loaderIcon);
			clickElementJS(labeldropdown);
			waitForInvisibility(loaderIcon);
			clickElementJS(labeldropdownValue);
			waitForInvisibility(loaderIcon);
			clickElement(clickSide);

			clickElementJS(labelTypedropdown);
			waitForInvisibility(loaderIcon);
			clickElementJS(labelTypedropdownValue);
			waitForInvisibility(loaderIcon);
			clickElement(clickSide);
		}
	}

	public String verifyCalendar() 
	{
		waitForInvisibility(loaderIcon);
		clickElementJS(calendar);
		waitForInvisibility(loaderIcon);

		@SuppressWarnings({ "rawtypes", "unchecked" })
		ArrayList browserTabs = new ArrayList(driver.getWindowHandles());
		driver.switchTo().window((String) browserTabs.get(1));

		return lblmyCalendar.getText();
	}

	public boolean verifySwitchingTabs() 
	{
		try 
		{
			selectDropdown();
		} 
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		clickElementJS(amenityTab);
		waitForInvisibility(loaderIcon);

		try 
		{
			pressEscapeKey();
			waitForInvisibility(loaderIcon);
		} 
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		clickElementJS(communityTab);
		waitForInvisibility(loaderIcon);

		try 
		{
			pressEscapeKey();
			waitForInvisibility(loaderIcon);
		} 

		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		if (isElementDisplayed(addNewButton))
		{
			return true;
		}
		else
		{
			return false;
		}

	}

	public boolean verifyLiteModeButton() 
	{
		try 
		{
			selectDropdown();
		} 
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		clickElementJS(liteModeButtonOff);
		waitForInvisibility(loaderIcon);

		System.out.println("Lite Mode is OFF.");

		try 
		{
			pressEscapeKey();
			waitForInvisibility(loaderIcon);
		} 
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		//Turn Lite Mode ON
		clickElementJS(liteModeButtonOn);
		waitForInvisibility(loaderIcon);

		if (isElementDisplayed(addNewButton))
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	public boolean verifyAddNewButtonappointmentDaily() 
	{
		try 
		{
			selectDropdown();
			AddNewButtonappointment();
		}
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		// Scroll to the element using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", recurrencedaily);

		clickElement(recurrencedaily);

		clickElement(okAppointmentButton);
		waitForInvisibility(loaderIcon);

		try 
		{
			contextisrequiredClosepopup();
		} 
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		return true;
	}

	public boolean verifyAddNewButtonappointmentWeekly() 
	{
		try 
		{
			selectDropdown();
			AddNewButtonappointment();
		}
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", recurrence);

		clickElement(recurrence);

		waitForInvisibility(loaderIcon);

		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", recurrenceWeekly);

		clickElement(recurrenceWeekly);

		// Click the element 3 times using a for loop
		for (int i = 0; i < 3; i++) 
		{
			clickElement(recureveryWeeks);
			System.out.println("Clicked " + (i+1) + " time(s).");
		}

		try
		{
			endbySelections();
			contextisrequiredClosepopup();
		} 
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		return true;
	}

	public boolean verifyAddNewButtonappointmentMonthly() 
	{
		try 
		{
			selectDropdown();

			AddNewButtonappointment();
		}
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", recurrence);

		clickElement(recurrence);

		waitForInvisibility(loaderIcon);

		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", recurrenceMonthly);

		clickElement(recurrenceMonthly);

		// Click the element 3 times using a for loop
		for (int i = 0; i < 3; i++) 
		{
			clickElement(monthlyDaydropdownValue);
			waitForInvisibility(loaderIcon);
			clickElement(monthlyEverymonthsdropdownValue);
			System.out.println("Clicked " + (i+1) + " time(s).");
		}

		clickElement(monthlyendby);

		// Get today's date
		LocalDate today = LocalDate.now();

		// Add one day to get tomorrow's date
		LocalDate tomorrow = today.plusDays(1);

		// Define the date format you need
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

		// Format tomorrow's date as a string
		String tomorrowDate = tomorrow.format(formatter);

		// Use sendKeys to enter tomorrow's date in the web element
		// Assuming addEditAnnouncementExpires is the WebElement for the expiration date field

		monthlyendbydate.sendKeys(tomorrowDate);
		waitForInvisibility(loaderIcon);

		clickElement(okAppointmentButton);
		waitForInvisibility(loaderIcon);

		try
		{
			contextisrequiredClosepopup();
		} 
		catch (AWTException e) 
		{
			e.printStackTrace();
		}
		return true;
	}

	public boolean verifyAddNewButtonappointmentYearly() 
	{
		try 
		{
			selectDropdown();

			AddNewButtonappointment();
		}
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", recurrence);

		clickElement(recurrence);

		waitForInvisibility(loaderIcon);

		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", recurrenceYearly);

		clickElement(recurrenceYearly);

		clickElement(yearlyEveryDropdown);
		clickElement(yearlyEveryJanuary);
		clickElement(yearlyEverynumberdropdwon);

		// Get today's date
		LocalDate today = LocalDate.now();

		// Add one day to get tomorrow's date
		LocalDate tomorrow = today.plusDays(1);

		// Define the date format you need
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

		// Format tomorrow's date as a string
		String tomorrowDate = tomorrow.format(formatter);

		// Use sendKeys to enter tomorrow's date in the web element
		// Assuming addEditAnnouncementExpires is the WebElement for the expiration date field
		clickElement(yearlyendby);

		yearlyendbydate.sendKeys(tomorrowDate);
		waitForInvisibility(loaderIcon);

		clickElement(okAppointmentButton);
		waitForInvisibility(loaderIcon);

		try
		{
			contextisrequiredClosepopup();
		} 
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		return true;
	}

	public boolean verifyAddNewButtonrecurringAppointmentDaily() 
	{
		try 
		{
			selectDropdown();
			waitForInvisibility(loaderIcon);
			AddNewButtonrecurringAppointment();
		} 
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		// Scroll to the element using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", visibleinResidentPortal);

		// Click the element
		clickElement(visibleinResidentPortal);
		//waitForInvisibility(loaderIcon);

		// Scroll to the element using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", recurrencedaily);

		recurringAppointmentendbySelections();

		return true;
	}


	public boolean verifyAddNewButtonrecurringAppointmentWeekly() 
	{
		try 
		{
			selectDropdown();
			waitForInvisibility(loaderIcon);
			AddNewButtonrecurringAppointment();
		} 
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		// Scroll to the element using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", visibleinResidentPortal);

		// Click the element
		clickElement(visibleinResidentPortal);
		waitForInvisibility(loaderIcon);

		// Scroll to the element using JavaScript
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", recurringAppointmentRecurrenceWeekly);

		clickElement(recurringAppointmentRecurrenceWeekly);

		// Click the element 3 times using a for loop
		for (int i = 0; i < 3; i++) 
		{
			clickElement(recurringAppointmentRecureveryWeeks);
			System.out.println("Clicked " + (i+1) + " time(s).");
		}

		recurringAppointmentendbySelections();

		return true;

	}

	public boolean verifyAddNewButtonrecurringAppointmentMonthly() 
	{
		try 
		{
			selectDropdown();
			waitForInvisibility(loaderIcon);
			AddNewButtonrecurringAppointment();
		} 
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", recurrence);

		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", recurringAppointmentMonthly);

		clickElement(recurringAppointmentMonthly);

		// Click the element 3 times using a for loop
		for (int i = 0; i < 3; i++) 
		{
			clickElement(recurringAppointmentmonthlyDaydropdownValue);
			waitForInvisibility(loaderIcon);
			clickElement(recurringAppointmentmonthlydropdownValue);
			System.out.println("Clicked " + (i+1) + " time(s).");
		}

		clickElement(recurringAppointmentMonthlyendby);

		// Get today's date
		LocalDate today = LocalDate.now();

		// Add one day to get tomorrow's date
		LocalDate tomorrow = today.plusDays(1);

		// Define the date format you need
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

		// Format tomorrow's date as a string
		String tomorrowDate = tomorrow.format(formatter);

		// Use sendKeys to enter tomorrow's date in the web element

		recurringAppointmentMonthlyendbydate.sendKeys(tomorrowDate);
		waitForInvisibility(loaderIcon);

		clickElement(okAppointmentButton);
		waitForInvisibility(loaderIcon);

		return true;

	}

	public boolean verifyAddNewButtonrecurringAppointmentYearly() 
	{
		try 
		{
			selectDropdown();

			AddNewButtonappointment();
		}
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", recurrence);

		clickElement(recurrence);

		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", recurringAppointmentRecurrenceYearly);

		clickElement(recurringAppointmentRecurrenceYearly);

		clickElement(recurringAppointmentYearlyEveryDropdown);
		clickElement(recurringAppointmentYearlyEveryJanuary);
		clickElement(recurringAppointmentYearlyEverynumberdropdwon);

		// Get today's date
		LocalDate today = LocalDate.now();

		// Add one day to get tomorrow's date
		LocalDate tomorrow = today.plusDays(1);

		// Define the date format you need
		DateTimeFormatter formatter = DateTimeFormatter.ofPattern("MM/dd/yyyy");

		// Format tomorrow's date as a string
		String tomorrowDate = tomorrow.format(formatter);

		// Use sendKeys to enter tomorrow's date in the web element
		// Assuming addEditAnnouncementExpires is the WebElement for the expiration date field
		clickElement(recurringAppointmentYearlyendby);

		recurringAppointmentYearlyendbydate.sendKeys(tomorrowDate);
		waitForInvisibility(loaderIcon);

		clickElement(okAppointmentButton);
		waitForInvisibility(loaderIcon);

		try
		{
			contextisrequiredClosepopup();
		} 
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		return true;
	}

	public boolean verifydayWiseCalenderCommunityTab() 
	{
		try 
		{
			selectDropdown();
			waitForInvisibility(loaderIcon);

			clickElement(daySelection);
			waitForInvisibility(loaderIcon);

		}
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		return true;
	}

	public boolean verifyWorkWeekWiseCalenderCommunityTab() 
	{
		try 
		{
			selectDropdown();
			clickElement(workWeekSelection);
			waitForInvisibility(loaderIcon);

		}
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		return true;
	}

	public boolean verifyWeekWiseCalenderCommunityTab() 
	{
		try 
		{
			selectDropdown();
			clickElement(weekSelection);
			waitForInvisibility(loaderIcon);

		}
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		return true;
	}

	public boolean verifyMonthWiseCalenderCommunityTab() 
	{
		try 
		{
			selectDropdown();
			clickElement(monthSelection);
			waitForInvisibility(loaderIcon);

		}
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		return true;
	}

	public boolean verifytimelineWiseCalenderCommunityTab() 
	{
		try 
		{
			selectDropdown();
			clickElement(timelineSelection);
			waitForInvisibility(loaderIcon);

		}
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		return true;
	}

	public boolean verifyExportbutton() 
	{
		try
		{
			selectDropdown();
			waitForInvisibility(loaderIcon);
			clickElement(exportButton);
			waitForInvisibility(loaderIcon);

			Robot robot = new Robot();

			// Simulate pressing the Enter key
			robot.keyPress(KeyEvent.VK_ENTER);
			
			// Simulate releasing the Enter key
			robot.keyRelease(KeyEvent.VK_ENTER);
		}
		catch (AWTException e) 
		{
			e.printStackTrace();
		}

		return true;
	}
}
